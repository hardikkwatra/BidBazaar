# BidBazaar
BidBazaar is an e-auction website.
